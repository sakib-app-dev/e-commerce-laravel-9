<x-frontend.master>
    <x-slot:title>
      About
    </x-slot>
             <h1 class="text-primary text-center" style="font-weight: 600; font-size:80px;margin:120px 50px;">404 Not Found</h1>
             <p class="text-center"><a href="{{ route('home') }}" class="btn btn-warning mb-5">Back to Home page</a></p>
  
              
          </x-frontend.master>