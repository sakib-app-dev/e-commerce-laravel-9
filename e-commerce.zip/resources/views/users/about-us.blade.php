<x-frontend.master>
  <x-slot:title>
    About
  </x-slot>
              <!-- header -nav  -->



            <div class="about">
              <img class="about-us" src="{{ asset('/assets/users/images/about.gif') }}" alt="">
              
          </div>
          <h1 class="heading">About Us</h1>
         <div class="mt-5 container">
          <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Inventore, quisquam dolores voluptates voluptate reiciendis reprehenderit minima fugiat accusantium non officiis?</p>
          <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Inventore, quisquam dolores voluptates voluptate reiciendis reprehenderit minima fugiat accusantium non officiis?</p>
          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Exercitationem voluptatem id eligendi beatae recusandae unde ratione natus nostrum explicabo illum molestiae ipsum, aliquid vero? Doloribus quod qui similique temporibus quidem iusto accusantium architecto repellendus, placeat nulla est dolor, tenetur ad nihil! Tempora eum, amet obcaecati esse facilis ab animi, unde, quia dolore ducimus perferendis nemo. Ipsam tempora at, illo repellat dolorum totam nisi velit autem ullam veniam iure, praesentium quasi amet? Aliquam ipsum sed qui doloremque, nemo laboriosam voluptates at eum veniam pariatur excepturi, mollitia, vel cum dolorum. Perferendis error mollitia non nemo quaerat ipsa a officiis possimus natus, similique ullam accusamus! Libero reprehenderit laboriosam nisi soluta eveniet nam qui beatae temporibus excepturi voluptatibus molestiae minima aliquam error quo quis, in magnam culpa porro delectus ipsam impedit? Assumenda soluta possimus, accusantium tempora inventore exercitationem similique voluptate vero atque sunt dignissimos, illo libero culpa ab impedit quis rem numquam eos reprehenderit nihil totam qui? Eos maiores cumque recusandae a praesentium aperiam neque? Architecto explicabo numquam eveniet iste voluptates ea sed praesentium dicta, culpa, nihil cumque corrupti fugiat animi voluptatibus quam assumenda rem tempore provident quasi similique placeat. Omnis ipsam natus quas officiis facere ratione ipsum atque! Optio, laudantium minima quos animi iusto ab illo aperiam quidem quas ipsa eum aut maxime itaque? Cumque consequatur, animi, sunt quod fugit earum quas optio iusto ab eaque aut corrupti illo fuga nobis placeat ipsa exercitationem dolorum dignissimos! Voluptas repudiandae repellendus consequuntur. Fugiat suscipit consectetur aliquam adipisci dolores incidunt numquam, dolor laudantium omnis veritatis tenetur facilis id delectus, neque hic. Eos maxime eligendi tenetur minus numquam dolore est libero rem explicabo facilis? Sunt ad sapiente quaerat dolorum corporis fugiat, nihil, non natus dolore eveniet magni ullam quidem quas autem voluptas doloremque similique temporibus sed. Enim cumque a, perspiciatis harum molestias quibusdam repudiandae in! Inventore, veniam!</p>
         </div>

            
        </x-frontend.master>