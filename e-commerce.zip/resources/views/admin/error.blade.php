<x-admin.master>
<div class="error-body">
		<div class="agile-signup">	
			
			<div class="error-page">
				<img src="{{asset('/ui/admin/')}}/images/error.png" alt="">
			</div>
			
			<div class="go-back">
				<a href="{{ route('admin.dashboard')}}">Back To Home</a>
			</div>
			
			<!-- footer -->
			<div class="copyright">
				<p>© 2016 Colored . All Rights Reserved . Design by <a href="http://w3layouts.com/">W3layouts</a></p>
			</div>
			<!-- //footer -->
		</div>
	<script src="js/proton.js"></script>
</div>
</x-admin.master>

