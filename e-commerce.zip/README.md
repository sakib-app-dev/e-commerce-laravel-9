Project live link:  http://e-commerce-sakib.epizy.com/


1.git clone https://github.com/sakib-app-dev/e-commerce-laravel-9.git

2.composer update

3.cp .env.example .env

4.php artisan key:generate

5.php artisan db:seed

6.npm intall / npm update

7.npm run dev / npm run build

8.php artisan serve