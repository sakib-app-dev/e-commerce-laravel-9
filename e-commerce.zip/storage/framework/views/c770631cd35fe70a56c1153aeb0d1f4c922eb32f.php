<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.master','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontend.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('title', null, []); ?> 
    Thank You
   <?php $__env->endSlot(); ?>




<div class="offset-md-3 col-md-6">
            <h1 style="text-align:center;">Your Order Placement is Successful!</h1>
    <h3 style="text-align:center;">Thanks for Staying with Us </h3>
    <img class="tick" src="<?php echo e(asset('assets/users/')); ?>/images/tick.png">


  <a href="<?php echo e(route('users.invoice')); ?>" class="btn btn-success btn-lg mt-3 mx-auto d-grid mb-3">Download Invoice</a>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

            
 <?php /**PATH E:\xampp\htdocs\e-commerce\resources\views/users/thank-you.blade.php ENDPATH**/ ?>