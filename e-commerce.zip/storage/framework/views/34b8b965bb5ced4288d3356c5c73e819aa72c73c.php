
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.master','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontend.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('title', null, []); ?> 
    Product Details
   <?php $__env->endSlot(); ?>


            <h1 style="text-align:center;">Product Details</h1>
            <div class="offset-md-4 col-md-4 mb-3" style="border-bottom: 3px solid orangered"></div>
    <div class="container">
        <div class="row mt-5">
            <div class="col-md-4">
              <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <img src="<?php echo e(asset('public/storage/images/'.$image?->image)); ?>" class="card-img-top" height="250px" alt="...">
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="offset-md-2 col-md-6">
             <h4><?php echo e($product->title); ?></h4>
             <p><?php echo e($product->description); ?></p>
             <h2 class="mt-5" style="color:orange ;"><?php echo e($product->price); ?> BDT</h2>
             <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.message','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('forms.message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
              <form action="<?php echo e(route('users.add-to-cart',$product->id)); ?>" method="POST">  
                <div class="quantity d-flex">
                  <p class="mt-5">Quantity: </p>
                    <div class="" style="margin:40px 30px">
                      
                        <?php echo csrf_field(); ?>
                        <input type="number" name="qty" style="width:60px;height:48px;text-align: center;" step="1" min="1" value="1" name="" id="" col="4">
                      
                    </div> 
                </div>
                <?php if(auth()->guard()->check()): ?>
                <div class="last mt-5">
                    
                  <button type="submit" class="btn btn-primary btn-lg">Add to Cart</button>
                  <a href="<?php echo e(route('users.checkout')); ?>" class="btn btn-primary btn-lg">Buy Now</a>
                  
                </div>
                <?php endif; ?>
              </form>

             
             

            </div>
            <div class="offset-md-1 col-md-10">
              <h1>Comments:</h1>
              <p>
                <form action="<?php echo e(route('users.products.comment.store',$product->id)); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.textarea','data' => ['name' => 'comment']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('forms.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'comment']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                  <button type="submit" class="btn btn-primary">Comment</button>
                </form>
              </p>
            </div>
            <div class="offset-md-1 col-md-10">
              <?php $__currentLoopData = $product->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-light border border-primary rounded" >
                  <h6><?php echo e($comment->commentedBy->name.' '); ?><sub><small><mark><?php echo e($comment->created_at->diffForHumans()); ?></mark></small></sub></h6><hr>
                  <p class=""><?php echo e($comment->comment); ?></p>
                </div>
                  
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <h5></h5>
            </div>
        </div>
        
        
    </div>



   <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

            
   <?php /**PATH E:\xampp\htdocs\e-commerce\resources\views/users/product-detail.blade.php ENDPATH**/ ?>