
  
              <!-- header -nav  -->

<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.master','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontend.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('title', null, []); ?> 
    Product List
   <?php $__env->endSlot(); ?>

            <h1 style="text-align:center;">Products</h1>
            <div class="offset-md-4 col-md-4 mb-3" style="border-bottom: 3px solid orangered"></div>
              <div class="container">
                  <div class="row">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                    
                      <div class="col-md-3 my-3">
                          <div class="card" style="width: 18rem;">
                            
                            <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <img src="<?php echo e(asset('storage/images/'.$image?->image)); ?>" class="card-img-top" height="250px" alt="...">
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                            
                              <div class="card-body text-center">
                                <h5 class="card-title"><?php echo e($product->title); ?></h5>
                                <p class="card-text fs-4 fw-bold"><?php echo e($product->price); ?>BDT</p>
                                <p>
                                  <span>
                                    <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                    <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                    <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                    <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                    <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                  </span>
                                </p>
                                <a href="<?php echo e(route('users.product.detail',$product->id)); ?>" class="btn btn-primary">Buy Now</a>
                              </div>
                            </div>
                      </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                      <?php echo e($products->links()); ?>

                      
                  </div>
              </div>

            
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH E:\xampp\htdocs\e-commerce\resources\views/users/product-list.blade.php ENDPATH**/ ?>