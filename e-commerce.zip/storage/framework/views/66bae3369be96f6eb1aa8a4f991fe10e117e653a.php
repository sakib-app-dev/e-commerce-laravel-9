<?php if(session('message')): ?>
<p class="text-success">
    <?php echo e(session('message')); ?>

</p>
<?php endif; ?><?php /**PATH E:\xampp\htdocs\e-commerce\resources\views/components/forms/message.blade.php ENDPATH**/ ?>